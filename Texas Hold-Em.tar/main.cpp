// Author: Amos Gurung
// File: main.cpp
// This is a test main class to run the texas hold-em program it will be replaced

#include "texasholdem.h"
#include <iostream>
int main()
{
    texasholdem::GurungStartGame();
    return 0;
}
